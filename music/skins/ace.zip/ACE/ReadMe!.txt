ReadMe!.txt  --  Ace for WinAmp 2.x
-----------------------------------

I was already working on this one before I began at the Perfect Circle Design skin.
So, after a time of hard labor, it's finished.
I tried the same kinda design like my older skin Zenithanian.
Only this time the display totally black, with the green letters.
Also the light effect on the top of the display's look rather cool I think.
On the buttons, you will get the real push feeling.

--------------------
Created in/with:
1280*1024
32 Bpp
Adobe Photoshop 6.01
MS Paint
MS Notepad
--------------------

To get the best results with the playlist, please download this font from my site:
http://www.smar.nl/Fonts/chromefnd10.zip

The font is created by the ShyFonts Type Foundry -- http://www.shyfonts.com.
Really cool fonts there.

________________________________________

Site: http://www.smar.nl
General Mail: info@smar.nl
About skins: skins@smar.nl
________________________________________


Greetz,

-=SMAR=-


(D) 2001 - SMAR Designs
Registered Design