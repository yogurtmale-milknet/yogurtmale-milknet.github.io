Star Trek P.A.D.D. Skin for winamp

Version 2

Email eiledon@bigfoot.com

Another winamp 2.x skin inspired by Star Trek, this time based around the PADD device used in the Next Generation. AVS added.

--------------------------------------------------------------------

If you like this check out my other skins at 1001winampskins:

TricorderMP3:

http://www.1001winampskins.com/skin_details.html?id=235

PanasonicXBS:

http://www.1001winampskins.com/skin_details.html?id=280

--------------------------------------------------------------------
