Commodore 64 - a skin in the style of Commodore 64

Altered from Old_X-timey by sburke@cpan.org, 02005-11-05
  which is altered from XawMMS by sburke@cpan.org 02005-09-13
    which is by Christopher Allen <cpcallen@ruah.dyndns.org>
      which is based on NeXTAmp2 v1.0pre1 by Jesse Kaufman <glandix@linuxfreak.com>
