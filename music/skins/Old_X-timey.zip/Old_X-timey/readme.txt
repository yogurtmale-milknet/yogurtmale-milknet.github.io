Old_X-timey - a skin in the style of some horrible monochrome past

Altered from XawMMS by sburke@cpan.org 02005-09-13
  which is by Christopher Allen <cpcallen@ruah.dyndns.org>
    which is based on NeXTAmp2 v1.0pre1 by Jesse Kaufman <glandix@linuxfreak.com>
