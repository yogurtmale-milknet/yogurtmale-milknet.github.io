#!/usr/bin/perl
#  -*-coding:latin-1;-*-  �sburke�   Time-stamp: "2005-11-14 21:24:54 AST"  �
use constant DEBUG => 10;
use strict;
use warnings;

print "<table cellpadding=0 cellspacing=0>\n";
for my $x (0 .. 16) {
  print "\t<tr>\n";
  for my $y (0 .. 125) {
    printf "\t\t<td bgcolor='%s'>&nbsp;</td>\n", random_color();
  }
  print "\t</tr>\n";
}
print "</table>\n";


sub random_color {
  return sprintf "#%02x%02x%02x", map int(rand(256)), 0,0,0;
}

__END__
